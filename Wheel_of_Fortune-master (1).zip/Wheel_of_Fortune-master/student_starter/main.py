# Rules
print('Guess one letter at a time. If you want to buy a vowel, you must have at least $500, otherwise, you cannot buy a vowel. If you think you know the word or phrase, type \'guess\' to guess the word or phrase. You will earn each letter at a set amount and vowels will not cost anything.')

from random import randint

# needed for your test cases so your random outputs would match ours
random.seed(3)

# List of letters to remove after each guess

# List of all vowels

# Categories and words

# Pick a random category

# Get a random word or phrase from the category

# Fill up list with blanks for characters in word

# Function to print Word
def printWord(word):



# Keep guessing until word is guessed correctly
while True:
    while True:
        # Pick a random amount from amounts

        # If the user wants to guess phrase or word

        # If the user guesses letter they've already guessed

        # If guess is a vowel, subtract $500 from total per vowel

        # If the user cannot buy vowel

        # If everything else is False, remove letter from alphabet and replace char in Word with letter in word

    # If word or phrase is fully guessed, end game
